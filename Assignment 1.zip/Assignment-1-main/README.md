# Assignment-1
CST-8359 .NET Application Dev. - Assignment 1 (School Community)

Rutvik Patel - 040915445
Alpesh Patel - 040923083
